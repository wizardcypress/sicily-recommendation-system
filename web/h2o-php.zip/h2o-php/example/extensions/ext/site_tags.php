<?php

class Site_Tag extends Tag {
    function render($context, $stream) {
        $stream->write('This is my site');
    }
}


h2o::addTag('site');

?>